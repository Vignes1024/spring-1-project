package com.tns.customerservice;

public interface Shopingmall_Repository {

}
