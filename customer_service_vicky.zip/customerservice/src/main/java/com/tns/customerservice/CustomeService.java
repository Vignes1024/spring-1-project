package com.tns.customerservice;

public class CustomeService {

}
